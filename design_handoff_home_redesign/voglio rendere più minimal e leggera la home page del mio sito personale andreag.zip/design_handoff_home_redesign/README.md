# Handoff: Redesign home page andreagalliani.com

## Overview
Redesign della home page del sito personale di Andrea Galliani, dal tema scuro slate/amber attuale a una direzione **minimale, chiara e leggera, stile Apple**. La home presenta la persona (personal brand) e porta al blog "Costruire in pubblico" (progetti HAB e Oxymeter), con una sezione progetti selezionati e i contatti. Tutto **bilingue IT/EN**.

## Screenshots
Anteprima delle sezioni (stato IT):
1. Hero — `screenshots/01-section.png`
2. Blog "Costruire in pubblico" (fondo scuro) — `screenshots/02-section.png`
3. Progetti selezionati (elenco denso) — `screenshots/03-section.png`
4. Footer / Contatti — `screenshots/04-section.png`

Versione mobile (layout impilato, ~390px):
- Hero mobile — `screenshots/01-mobile.png`
- Blog mobile — `screenshots/02-mobile.png`
- Progetti mobile — `screenshots/03-mobile.png`

## About the Design Files
Il file in questo bundle (`AndreaGalliani-Home.dc.html`) è un **riferimento di design creato in HTML**: un prototipo che mostra look e comportamento desiderati, **non codice di produzione da copiare così com'è**. L'obiettivo è **ricreare questo design nel codebase reale** `agalliani.github.io` (Vue 3 + Vite + Tailwind), usando i pattern e le convenzioni già presenti nel repo (componenti, composables, config Tailwind). Riusa dati, immagini e link già nel repo; non introdurre URL inventati.

> Nota tecnica sul file: è un "Design Component" e usa una sintassi di template propria (`{{ ... }}`, `sc-for`, `style-hover`). Trattalo come specifica visiva, non come sorgente Vue.

## Fidelity
**High-fidelity (hifi).** Colori, tipografia, spaziature e interazioni sono definitivi. Ricrea l'UI in modo fedele usando le librerie/pattern del codebase.

## Screens / Views

### Home (pagina unica, scroll verticale)
Ordine sezioni: Header sticky → Hero → Blog (fondo scuro) → Progetti → Footer/Contatti.
Contenitore centrale max-width **1080px** (hero fino a 1200px), centrato.

#### 1. Header (sticky)
- **Layout**: flex, space-between, align-center. Padding `18px clamp(24px,5vw,48px)`. `position: sticky; top:0`. Bordo inferiore `1px solid #e8e8ed`. Sfondo `rgba(255,255,255,.8)` con `backdrop-filter: saturate(180%) blur(20px)`. `z-index:10`.
- **Sinistra**: nome "Andrea Galliani", font-weight 600, 19px, letter-spacing -.02em.
- **Destra (nav)**: flex gap 34px, font 15px. Voci: Chi sono / Progetti / Blog (weight 500) / Contatti — colore `#1d1d1f`. Poi pill toggle lingua: bordo `1px solid #d2d2d7`, trasparente, padding `6px 12px`, radius 980px, 13px/600, testo "EN" (se lingua IT) o "IT" (se EN).

#### 2. Hero
- **Layout**: grid `1.15fr .85fr`, gap 80px, align-center. Padding `clamp(64px,10vw,120px) clamp(24px,5vw,48px)`, max-width 1200px.
- **Sinistra**:
  - Kicker: 14px, letter-spacing .12em, uppercase, `#86868b`, weight 500. Testo = `role`.
  - `<h1>` "Andrea Galliani" (su due righe): 76px, line-height 1.02, letter-spacing -.03em, weight 600.
  - Tagline: 26px, line-height 1.32, weight 500, max-width 480px, margin-top 28px. Testo = `heroTag`.
  - Lead: 19px, line-height 1.6, `#6e6e73`, max-width 500px, margin-top 22px. Testo = `heroLead`.
  - CTA (flex gap 14px, margin-top 40px): primaria "Leggi il blog" (bg `#0071e3`, testo bianco, padding `14px 28px`, radius 980px, 16px/500); secondaria "Guarda i progetti" (bg `#f5f5f7`, testo `#1d1d1f`).
- **Destra**: card ritratto, `aspect-ratio 4/5`, radius 28px, overflow hidden, bg `#f5f5f7`, `box-shadow:0 30px 70px rgba(0,0,0,.14)`. Immagine `propic.webp`, `object-fit:cover`.

#### 3. Blog — "Costruire in pubblico" (fondo scuro)
- **Sezione**: bg `#1d1d1f`, testo `#f5f5f7`, padding `clamp(64px,10vw,120px) clamp(24px,5vw,48px)`. Contenuto max-width 1080px.
- **Intestazione**: kicker serif italic (Newsreader) 22px colore `#6ab0ff`; titolo (Newsreader) 48px, line-height 1.1, weight 500; lead 19px `#a1a1a6`, max-width 600px.
- **Griglia**: `grid` `repeat(auto-fit, minmax(340px,1fr))`, gap 28px, margin-top 56px.
- **Card (x2: HAB, Oxymeter)**: `<a>`, bg `#242426`, bordo `1px solid #3a3a3c`, radius 24px, overflow hidden. Transition transform/box-shadow/border .25s. Hover: `translateY(-4px)`, `box-shadow:0 24px 60px rgba(0,0,0,.4)`, border `#5a5a5e`.
  - **Media** `aspect-ratio 16/9`:
    - Oxymeter → immagine reale `oxymeter-hero.png`, `object-fit:cover`, hover `scale(1.04)` (transition .5s).
    - HAB → **nessuna foto reale disponibile**: pannello a tema "stratosfera" con gradiente `linear-gradient(180deg,#0b1a3a 0%,#22467e 45%,#7db0e6 100%)`, qualche "stella" (radial-gradient bianchi), label mono in basso a sinistra "↑ 35.000 m". Sostituire con foto reale quando disponibile.
  - **Corpo** padding `32px 32px 34px`: riga con label mono (11px, uppercase, `#8e8e93`) + badge "Prossimamente" (11px/600, uppercase, colore `#6ab0ff`, bordo `1px solid #3a5a7a`, padding `4px 10px`, radius 980px); titolo serif (Newsreader) `clamp(28px,3.4vw,36px)`, weight 500, colore `#fff`; testo 16px `#a1a1a6`.
- Il blog è **"in arrivo"**: badge Prossimamente, nessun articolo reale. Non generare post finti.

#### 4. Progetti selezionati (fondo bianco, elenco denso)
- **Sezione**: padding `clamp(64px,10vw,120px) clamp(24px,5vw,48px)`, max-width 1080px.
- **Intestazione**: kicker 14px uppercase `#86868b`; titolo 46px weight 600; lead 19px `#6e6e73`, max-width 560px.
- **Griglia**: `grid` `repeat(auto-fit, minmax(400px,1fr))`, gap `14px 40px`, margin-top 48px. (2 colonne su desktop, 1 su mobile.)
- **Voce (riga)**: `<a>` grid `96px 1fr auto`, gap 20px, align-center, padding 16px, radius 16px. Hover: `background:#f5f5f7` (transition .2s).
  - Miniatura: `aspect-ratio 1`, radius 12px, overflow hidden, `object-fit:cover`. Bg `#f0f0f2` (web) o `#111` (chip).
  - Centro: riga titolo (18px/600, letter-spacing -.01em) + tag mono inline (11px, uppercase, `#86868b`); sotto descrizione 14px, line-height 1.45, `#6e6e73`.
  - Destra: freccia `→` 18px, colore `#c7c7cc`.
- **Voci** (con link reali dal repo):
  1. **Timeline Me** — tag "Web app" — `https://agalliani.github.io/timeline-me/` — img `timeline-me-hero.png`
  2. **Dalila Scollo** — tag "Web design" — `https://dalilascollo.com/` — img `dalila-portfolio-hero.png`
  3. **PiHEX** — tag "CMOS 28nm" — `https://www.dei.unipd.it/system/files/PRIN2022_PiHEX_Gerardin_0.pdf` — img `pihex chip`
  4. **Falaphel** — tag "ASIC · Ph.D." — `https://www.sciencedirect.com/science/article/abs/pii/S0168900224007885` — img `FLASH_AFE_FALAPHEL_chip_v20.png`
- Sotto la lista: link "Tutti i progetti →" 17px/500.

#### 5. Footer / Contatti
- **Sezione**: bg `#f5f5f7`, bordo superiore `1px solid #e8e8ed`, padding `clamp(64px,9vw,110px) clamp(24px,5vw,48px) 56px`. Contenuto max-width 1080px.
- **Layout**: flex space-between, align-flex-end, wrap, gap 40px.
  - Sinistra: kicker "Contatti" uppercase; titolo "Parliamone" 44px/600; lead 19px `#6e6e73`, max-width 460px.
  - Destra: colonna link (17px/500, allineati a destra): Email `mailto:andrea.galliani.29@gmail.com`, LinkedIn `https://www.linkedin.com/in/andreagalliani`, GitHub `https://github.com/agalliani`, Google Scholar `https://scholar.google.com/citations?user=mReBtJQAAAAJ&hl=it`.
- Riga finale: "© 2026 Andrea Galliani", 13px `#86868b`, bordo superiore, padding-top 28px.

## Interactions & Behavior
- **Toggle lingua**: cambia una variabile reattiva `lang` ('it' | 'en'); tutte le stringhe vengono da un dizionario. Il bottone mostra la lingua opposta.
- **Hover card blog**: lift `translateY(-4px)` + ombra più marcata + zoom immagine `scale(1.04)`.
- **Hover riga progetto**: sfondo `#f5f5f7`.
- **Link colori**: default `#0071e3`; underline on hover.
- **Responsive**: layout guidato da `minmax()` + `clamp()`, senza media query dove possibile. Hero e liste si impilano naturalmente su mobile. Hit target ≥44px.

## State Management
- `lang: 'it' | 'en'` (default 'it'). Unico stato necessario. Consigliato un composable `useI18n()` o un oggetto `messages` reattivo con chiavi `it`/`en`.
- Testi centralizzati (esempi di chiavi): `role, heroTag, heroLead, ctaBlog, ctaWork, blogKicker, blogTitle, blogLead, blogSoon, workKicker, workTitle, workLead, view, contactKicker, contactTitle, contactLead` + copy per card blog (`habLabel, habLead, oxyLabel, oxyLead`) e sub progetti (`tl, dalila, pihex, falaphel`). Testi definitivi IT/EN nel file HTML di riferimento.

## Design Tokens
**Colori**
- Sfondo: `#ffffff` · Testo: `#1d1d1f` · Grigi testo: `#6e6e73`, `#86868b`
- Superfici chiare: `#f5f5f7`, `#f0f0f2` · Bordi: `#e8e8ed`, `#d2d2d7`
- Accento: `#0071e3` · Freccia inattiva: `#c7c7cc`
- Blog scuro: bg sezione `#1d1d1f`, card `#242426`, bordi `#3a3a3c`/`#5a5a5e`, testo `#a1a1a6`/`#8e8e93`, accento chiaro `#6ab0ff`, bordo badge `#3a5a7a`
- Gradiente HAB (placeholder): `#0b1a3a → #22467e → #7db0e6`

**Tipografia**
- UI: `-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Helvetica Neue', Helvetica, Arial, sans-serif`
- Titoli blog: **Newsreader** (serif), pesi 400–600, con variante italic
- Mono (label/tag): `ui-monospace, 'SF Mono', monospace`
- Scala: h1 76px · titoli sezione 44–48px · titolo card blog `clamp(28px,3.4vw,36px)` · titolo progetto 18px · corpo 15–19px · kicker/label 11–14px

**Spaziatura**
- Padding sezione: `clamp(64px,10vw,120px)` vert / `clamp(24px,5vw,48px)` oriz
- Gap griglie: blog 28px · progetti `14px 40px` · nav 34px

**Radius**: header pill/badge/CTA 980px · card blog 24px · card ritratto 28px · riga progetto 16px · miniatura 12px

**Ombre**: ritratto `0 30px 70px rgba(0,0,0,.14)` · hover card blog `0 24px 60px rgba(0,0,0,.4)`

## Assets
Tutti presenti nel repo `agalliani.github.io`:
- `public/propic.webp` — ritratto hero
- `src/assets/images/web-apps/oxymeter-hero.png` — card blog Oxymeter
- `src/assets/images/web-apps/timeline-me-hero.png` — progetto Timeline Me
- `src/assets/images/web-apps/dalila-portfolio-hero.png` — progetto Dalila Scollo
- `src/assets/images/deep-tech/pihex/BILINEAR_PRIN_FULLCHIP_3.png` — progetto PiHEX
- `src/assets/images/deep-tech/falaphel/FLASH_AFE_FALAPHEL_chip_v20.png` — progetto Falaphel
- **HAB**: nessuna immagine reale ancora → usare il pannello gradiente a tema come placeholder.

## Files
- `AndreaGalliani-Home.dc.html` — prototipo di riferimento hifi (in questo bundle). Contiene markup, stili inline e tutte le stringhe IT/EN definitive.
